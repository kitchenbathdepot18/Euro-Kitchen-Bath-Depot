const Footer = () => {
  const footerLinks = {
    "Get Ideas": ["Gallery", "Kitchens", "Bathrooms", "Other Rooms"],
    "Style & Design": ["Door Styles", "Finishes", "Wood Species", "Hardware"],
    "Resources & Tips": ["FAQ", "Care & Cleaning", "Warranty", "Blog"],
    "Plan a Project": ["Find a Dealer", "Kitchen Visualizer", "Request Info", "Design Centers"],
  };

  return (
    <footer className="bg-foreground text-primary-foreground">
      {/* Find Dealer CTA */}
      <div className="text-center py-12 md:py-16 border-b border-primary-foreground/10" id="dealer">
        <h2 className="font-display text-2xl md:text-3xl tracking-[0.15em] uppercase mb-6">
          Find Your Local Dealer
        </h2>
        <a
          href="#"
          className="inline-block border border-primary-foreground/60 text-primary-foreground px-8 py-3 text-xs tracking-[0.15em] uppercase font-body hover:bg-primary-foreground hover:text-foreground transition-all duration-300"
        >
          Search Dealers
        </a>
      </div>

      {/* Footer links */}
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-body text-xs tracking-[0.15em] uppercase mb-4 text-primary-foreground/80">
                {category}
              </h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="font-body text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-primary-foreground/10 px-6 lg:px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-col items-center md:items-start">
            <span className="font-display text-xl tracking-[0.2em] uppercase font-semibold">
              Showplace
            </span>
            <span className="font-body text-[9px] tracking-[0.35em] uppercase text-primary-foreground/60 mt-0.5">
              Cabinetry
            </span>
          </div>
          <div className="flex gap-6 text-xs text-primary-foreground/50">
            <a href="#" className="hover:text-primary-foreground transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary-foreground transition-colors">Terms of Use</a>
            <span>© 2026 Showplace Cabinetry</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
