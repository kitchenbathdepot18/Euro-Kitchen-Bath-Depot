import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import heroKitchen1 from "@/assets/hero-kitchen-1.jpg";
import heroKitchen2 from "@/assets/hero-kitchen-2.jpg";
import heroKitchen3 from "@/assets/hero-kitchen-3.jpg";

const projects = [
  {
    title: "Elevated Elegance",
    designer: "Carissa Trygstad",
    location: "Showplace Cabinetry Design Center",
    city: "Sioux Falls/Harrisburg, SD",
    image: heroKitchen1,
  },
  {
    title: "Best of Both Worlds",
    designer: "Hammond Kitchen & Bath, LLC",
    location: "",
    city: "West Melbourne, FL",
    image: heroKitchen2,
  },
  {
    title: "Refined Simplicity",
    designer: "Advanced Cabinetry",
    location: "",
    city: "Auburn Hills, MI",
    image: heroKitchen3,
  },
];

const HeroCarousel = () => {
  const [current, setCurrent] = useState(0);

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % projects.length);
  }, []);

  const prev = useCallback(() => {
    setCurrent((prev) => (prev - 1 + projects.length) % projects.length);
  }, []);

  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, [next]);

  const project = projects[current];

  return (
    <section className="relative">
      {/* Main Image */}
      <div className="relative h-[60vh] md:h-[75vh] lg:h-[85vh] overflow-hidden">
        {projects.map((p, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              i === current ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={p.image}
              alt={p.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/50 via-foreground/10 to-transparent" />
          </div>
        ))}

        {/* Content overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 lg:p-14">
          <h2 className="font-display text-xl md:text-2xl tracking-[0.15em] uppercase text-background mb-2">
            {project.title}
          </h2>
          <p className="font-body text-sm text-background/80">
            Designed by {project.designer}
            {project.location && (
              <>
                {" "}at{" "}
                <span className="underline underline-offset-2">{project.location}</span>
              </>
            )}
            {" "}in {project.city}
          </p>
        </div>

        {/* See Project button */}
        <div className="absolute bottom-6 right-6 md:bottom-10 md:right-10">
          <a
            href="#"
            className="border border-background/80 text-background px-6 py-2.5 text-xs tracking-[0.15em] uppercase font-body hover:bg-background hover:text-foreground transition-all duration-300"
          >
            See Project
          </a>
        </div>

        {/* Navigation arrows */}
        <button
          onClick={prev}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center text-background/70 hover:text-background transition-colors"
          aria-label="Previous"
        >
          <ChevronLeft className="w-8 h-8" />
        </button>
        <button
          onClick={next}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center text-background/70 hover:text-background transition-colors"
          aria-label="Next"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      </div>

      {/* Project tabs */}
      <div className="flex justify-center gap-6 md:gap-10 py-6 px-4 overflow-x-auto">
        {projects.map((p, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`font-body text-sm tracking-wider whitespace-nowrap pb-1 transition-all duration-300 ${
              i === current
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {p.title}
          </button>
        ))}
      </div>
    </section>
  );
};

export default HeroCarousel;
