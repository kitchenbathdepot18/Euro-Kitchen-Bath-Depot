interface GalleryGridProps {
  images: {
    src: string;
    alt: string;
    label: string;
  }[];
  title: string;
  description: string;
  ctaText: string;
  ctaHref: string;
  reversed?: boolean;
}

const GalleryGrid = ({ images, title, description, ctaText, ctaHref, reversed = false }: GalleryGridProps) => {
  return (
    <section className="px-6 lg:px-8 py-8">
      <div className={`grid grid-cols-1 lg:grid-cols-2 gap-4 ${reversed ? 'lg:direction-rtl' : ''}`}>
        {/* Left column: two tall images stacked vertically isn't quite right. 
            Layout: top-left tall, top-right tall, bottom-left square, bottom-right wide */}
        <div className="grid grid-cols-2 gap-4">
          {/* Tall image 1 */}
          <div className="group relative overflow-hidden row-span-1">
            <img
              src={images[0].src}
              alt={images[0].alt}
              className="w-full h-full object-cover aspect-[9/16] transition-transform duration-700 group-hover:scale-105"
            />
            <div className="gallery-overlay" />
            <div className="gallery-label">
              <span className="font-display text-sm font-semibold">{images[0].label}</span>
            </div>
          </div>

          {/* Tall image 2 */}
          <div className="group relative overflow-hidden row-span-1">
            <img
              src={images[1].src}
              alt={images[1].alt}
              className="w-full h-full object-cover aspect-[9/16] transition-transform duration-700 group-hover:scale-105"
            />
            <div className="gallery-overlay" />
            <div className="gallery-label">
              <span className="font-display text-sm font-semibold">{images[1].label}</span>
            </div>
          </div>

          {/* Square image */}
          <div className="group relative overflow-hidden">
            <img
              src={images[2].src}
              alt={images[2].alt}
              className="w-full h-full object-cover aspect-square transition-transform duration-700 group-hover:scale-105"
            />
            <div className="gallery-overlay" />
            <div className="gallery-label">
              <span className="font-display text-sm font-semibold">{images[2].label}</span>
            </div>
          </div>

          {/* Text block in grid */}
          <div className="flex flex-col justify-center items-start p-4">
            <h2 className="section-heading text-2xl md:text-3xl mb-3">{title}</h2>
            <p className="section-subheading text-sm mb-4">{description}</p>
            <a
              href={ctaHref}
              className="font-body text-xs tracking-[0.15em] uppercase text-primary border-b border-primary pb-1 hover:text-copper-light transition-colors"
            >
              {ctaText}
            </a>
          </div>
        </div>

        {/* Right column: wide image */}
        <div className="group relative overflow-hidden">
          <img
            src={images[3].src}
            alt={images[3].alt}
            className="w-full h-full object-cover min-h-[400px] transition-transform duration-700 group-hover:scale-105"
          />
          <div className="gallery-overlay" />
          <div className="gallery-label">
            <span className="font-display text-sm font-semibold">{images[3].label}</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GalleryGrid;
