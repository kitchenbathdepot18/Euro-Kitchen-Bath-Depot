import { useState } from "react";
import { Search, ChevronDown, Menu, X } from "lucide-react";

const navItems = [
  { label: "WHAT'S NEW", href: "#whats-new" },
  { label: "GET IDEAS", href: "#gallery", hasDropdown: true },
  { label: "STYLE & DESIGN", href: "#style-design", hasDropdown: true },
  { label: "RESOURCE & TIPS", href: "#", hasDropdown: true },
  { label: "PLAN A PROJECT", href: "#", hasDropdown: true },
];

const topLinks = [
  { label: "Careers", href: "#" },
  { label: "Employee Portal", href: "#" },
  { label: "For Dealers", href: "#", hasDropdown: true },
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      {/* Top bar */}
      <div className="hidden lg:flex justify-end items-center px-8 py-2 text-xs tracking-wider">
        {topLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="text-muted-foreground hover:text-foreground transition-colors ml-6 flex items-center gap-1"
          >
            {link.label}
            {link.hasDropdown && <ChevronDown className="w-3 h-3" />}
          </a>
        ))}
      </div>

      {/* Main nav */}
      <div className="flex items-center justify-between px-6 lg:px-8 py-4">
        {/* Logo */}
        <a href="#" className="flex-shrink-0">
          <div className="flex flex-col leading-none">
            <span className="font-display text-2xl md:text-3xl tracking-[0.2em] uppercase font-semibold text-foreground">
              Showplace
            </span>
            <span className="font-body text-[10px] md:text-xs tracking-[0.35em] uppercase text-muted-foreground mt-0.5">
              Cabinetry
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="nav-link flex items-center gap-1 py-2"
            >
              {item.label}
              {item.hasDropdown && <ChevronDown className="w-3.5 h-3.5" />}
            </a>
          ))}
          <button className="text-foreground hover:text-primary transition-colors" aria-label="Search">
            <Search className="w-5 h-5" />
          </button>
        </nav>

        {/* CTA + Mobile toggle */}
        <div className="flex items-center gap-4">
          <a
            href="#dealer"
            className="hidden md:inline-block border border-primary text-primary px-5 py-2.5 text-xs tracking-[0.15em] uppercase font-body hover:bg-primary hover:text-primary-foreground transition-all duration-300"
          >
            Find Your Local Dealer
          </a>
          <button
            className="lg:hidden text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-border bg-background animate-fade-in">
          <nav className="flex flex-col px-6 py-4 gap-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="nav-link py-2"
                onClick={() => setMobileOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a
              href="#dealer"
              className="border border-primary text-primary px-5 py-2.5 text-xs tracking-[0.15em] uppercase font-body text-center hover:bg-primary hover:text-primary-foreground transition-all duration-300 mt-2"
            >
              Find Your Local Dealer
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
