interface FeatureCardProps {
  image: string;
  label: string;
  title: string;
  description: string;
  ctaText: string;
  ctaHref: string;
  reversed?: boolean;
}

const FeatureCard = ({ image, label, title, description, ctaText, ctaHref, reversed = false }: FeatureCardProps) => {
  return (
    <section className="py-10 md:py-16 px-6 lg:px-8">
      <div className={`grid grid-cols-1 lg:grid-cols-2 gap-0 items-stretch max-w-6xl mx-auto ${reversed ? 'lg:[direction:rtl]' : ''}`}>
        {/* Image */}
        <div className={`relative overflow-hidden ${reversed ? 'lg:[direction:ltr]' : ''}`}>
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover min-h-[350px] md:min-h-[450px]"
          />
          <div className="absolute top-6 left-6">
            <span className="font-body text-xs tracking-[0.2em] uppercase text-background bg-foreground/30 backdrop-blur-sm px-4 py-2">
              {label}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className={`flex flex-col justify-center bg-warm-cream p-8 md:p-12 lg:p-16 ${reversed ? 'lg:[direction:ltr]' : ''}`}>
          <h2 className="section-heading text-2xl md:text-3xl lg:text-4xl mb-4">{title}</h2>
          <p className="section-subheading mb-6">{description}</p>
          <a
            href={ctaHref}
            className="inline-block font-body text-xs tracking-[0.15em] uppercase text-primary border-b border-primary pb-1 hover:text-copper-light transition-colors self-start"
          >
            {ctaText}
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeatureCard;
