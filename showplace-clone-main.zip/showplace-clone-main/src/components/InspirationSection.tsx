const InspirationSection = () => {
  return (
    <section className="text-center py-16 md:py-20 px-6" id="gallery">
      <h2 className="section-heading mb-4">Inspiration Ahead</h2>
      <p className="section-subheading mx-auto">
        At Showplace, we craft cabinetry to fit your design tastes and budget. The result is a reliable, quality product you can enjoy for years to come.
      </p>
      <p className="font-body text-muted-foreground mt-3">
        Take a look at some of the possibilities that could inspire your next space.
      </p>
    </section>
  );
};

export default InspirationSection;
