interface FullWidthFeatureProps {
  image: string;
  title: string;
  description: string;
  ctaText: string;
  ctaHref: string;
}

const FullWidthFeature = ({ image, title, description, ctaText, ctaHref }: FullWidthFeatureProps) => {
  return (
    <section className="py-10 md:py-16 px-6 lg:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div className="overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-auto object-cover"
          />
        </div>
        <div className="flex flex-col justify-center">
          <h2 className="section-heading text-2xl md:text-3xl lg:text-4xl mb-4">{title}</h2>
          <p className="section-subheading mb-6">{description}</p>
          <a
            href={ctaHref}
            className="inline-block font-body text-xs tracking-[0.15em] uppercase text-primary border-b border-primary pb-1 hover:text-copper-light transition-colors self-start"
          >
            {ctaText}
          </a>
        </div>
      </div>
    </section>
  );
};

export default FullWidthFeature;
