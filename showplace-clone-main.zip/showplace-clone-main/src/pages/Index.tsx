import Header from "@/components/Header";
import HeroCarousel from "@/components/HeroCarousel";
import InspirationSection from "@/components/InspirationSection";
import GalleryGrid from "@/components/GalleryGrid";
import FeatureCard from "@/components/FeatureCard";
import FullWidthFeature from "@/components/FullWidthFeature";
import Footer from "@/components/Footer";

import galleryKitchen1 from "@/assets/gallery-kitchen-1.jpg";
import galleryKitchen2 from "@/assets/gallery-kitchen-2.jpg";
import galleryKitchen3 from "@/assets/gallery-kitchen-3.jpg";
import galleryKitchen4 from "@/assets/gallery-kitchen-4.jpg";
import galleryBath1 from "@/assets/gallery-bath-1.jpg";
import galleryBath2 from "@/assets/gallery-bath-2.jpg";
import galleryBath3 from "@/assets/gallery-bath-3.jpg";
import galleryBath4 from "@/assets/gallery-bath-4.jpg";
import galleryOther1 from "@/assets/gallery-other-1.jpg";
import galleryOther2 from "@/assets/gallery-other-2.jpg";
import galleryOther3 from "@/assets/gallery-other-3.jpg";
import galleryOther4 from "@/assets/gallery-other-4.jpg";
import whatsNewImg from "@/assets/whats-new.jpg";
import styleDesignImg from "@/assets/style-design.jpg";
import visualizerImg from "@/assets/visualizer.jpg";
import designCenterImg from "@/assets/design-center.jpg";

const kitchenImages = [
  { src: galleryKitchen1, alt: "Modern black kitchen cabinets", label: "See Project" },
  { src: galleryKitchen2, alt: "Warm stained wood kitchen cabinets", label: "See Project" },
  { src: galleryKitchen3, alt: "White and grey kitchen cabinets", label: "See Project" },
  { src: galleryKitchen4, alt: "White farmhouse kitchen", label: "See Project" },
];

const bathImages = [
  { src: galleryBath1, alt: "White inset bathroom vanity", label: "See Project" },
  { src: galleryBath2, alt: "Rustic stained bathroom vanity", label: "See Project" },
  { src: galleryBath3, alt: "Modern dark bathroom cabinets", label: "See Project" },
  { src: galleryBath4, alt: "Bright airy double vanity", label: "See Project" },
];

const otherImages = [
  { src: galleryOther1, alt: "Dark moody display hutch", label: "See Project" },
  { src: galleryOther2, alt: "Rustic retreat kitchen cabinets", label: "See Project" },
  { src: galleryOther3, alt: "Basement pub bar cabinetry", label: "See Project" },
  { src: galleryOther4, alt: "White dining hutch cabinetry", label: "See Project" },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroCarousel />
      <InspirationSection />

      <GalleryGrid
        images={kitchenImages}
        title="Kitchens"
        description="The heart of the home and where we hope our semi-custom kitchen cabinets bring you functionality and beauty."
        ctaText="View the Gallery"
        ctaHref="#"
      />

      <GalleryGrid
        images={bathImages}
        title="Bathrooms"
        description="See inspiration for the bathroom of your dreams! Or, see how new cabinets made the smallest of bathrooms come to life."
        ctaText="View the Gallery"
        ctaHref="#"
        reversed
      />

      <GalleryGrid
        images={otherImages}
        title="Other Rooms"
        description="Cabinetry can be used in almost any room in your home. See some of the other ways our semi-custom cabinets have been designed for offices, mudrooms, hallways, living rooms and more."
        ctaText="View the Gallery"
        ctaHref="#"
      />

      <div id="whats-new">
        <FeatureCard
          image={whatsNewImg}
          label="Explore"
          title="What's New"
          description="Evolution never stops. See the latest and greatest finishes available."
          ctaText="View Our Newest Options"
          ctaHref="#"
        />
      </div>

      <div id="style-design">
        <FeatureCard
          image={styleDesignImg}
          label="Discover"
          title="Style & Design"
          description="Browse through our many finishes to start getting ideas for your next project."
          ctaText="See Our Door Styles"
          ctaHref="#"
          reversed
        />
      </div>

      <FullWidthFeature
        image={visualizerImg}
        title="Kitchen Visualizer"
        description="Use our kitchen visualizer tool to pick from four sample scenes and then choose from our Showplace cabinet finishes to get an idea of what your dream kitchen could look like."
        ctaText="View More"
        ctaHref="#"
      />

      <FullWidthFeature
        image={designCenterImg}
        title="Looking for our Showplace Design Centers?"
        description="Showplace Cabinetry Design Center makes your dreams a reality by helping you envision, design, and accentuate any space with beautiful cabinetry."
        ctaText="Visit Design Centers"
        ctaHref="#"
      />

      <Footer />
    </div>
  );
};

export default Index;
